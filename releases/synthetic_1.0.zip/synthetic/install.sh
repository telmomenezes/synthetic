#!/bin/sh
cp synt.jar /usr/local/bin
cp synt /usr/local/bin
